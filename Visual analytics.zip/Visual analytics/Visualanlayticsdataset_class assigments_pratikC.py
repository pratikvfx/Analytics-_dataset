
# coding: utf-8

# In[15]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
import seaborn as sns


# In[19]:


#import data
df = pd.read_csv("D:\\Analytics_dataset\\Visual Analytics1.csv")


# In[21]:


df.head(10)


# In[22]:


df.info()


# In[23]:


df.describe(include='all')


# In[24]:


# Histogram of Continuous Variables
def plot_histogram(df, cols, bins = 20):
    for col in cols:
        fig = plt.figure(figsize=(6,6)) # define plot area
        ax = fig.gca() # define axis    
        df[col].plot.hist(ax = ax, bins = bins , color = 'c') # Use the plot.hist method on subset of the data frame
        ax.set_title('Histogram of  ' + col) # Give the plot a main title
        ax.set_xlabel(col) # Set text for the x axis
        ax.set_ylabel('Number of Cars')# Set text for y axis
        plt.show()
num_cols = ['Age','Balance']
plot_histogram(df, num_cols);


# # Heatmap of Numeric Features (Age and Balance)

# In[25]:


# heatmeap to see the correlation between features. 
plt.subplots(figsize = (8,8))
sns.heatmap(df.corr(), 
            annot=True,
            cmap = 'YlGnBu',
            linewidths=0.1, 
            linecolor='white',
            vmax = .9,
            square=True)
plt.title("Correlations Among Features", y = 1.03,fontsize = 20);


# # Inferences

# In[29]:


Age is Normally Distributed.Balance is "Right Skewed".

Lack of Correlation Between Age and Balance.


# # Bar Plot for Categorical Features

# In[30]:


def plot_bars(data, cols):
    for col in cols:
        fig = plt.figure(figsize=(6,6)) # define plot area
        ax = fig.gca() # define axis    
        counts = df[col].value_counts() # find the counts for each unique category
        counts.plot.bar(ax = ax, color = 'green') # Use the plot.bar method on the counts data frame
        ax.set_title('Number of Customers by ' + col) # Give the plot a main title
        ax.set_xlabel(col) # Set text for the x axis
        ax.set_ylabel('Number of Customers')# Set text for y axis
        plt.show()

plot_cols = ['Gender', 'Job Classification', 'Region']
plot_bars(df, plot_cols) 


# # Inferences

# Male Customers hold the maximum accounts
# 
# Whitecollared Customers hold the maximum accounts
# 
# England has the highest number of accounts

# # Box Plot for Categorical Features and Target

# In[31]:


sns.boxplot(x='Gender' , y='Balance' , data = df , palette = 'rainbow');


# In[32]:


sns.boxplot(x='Job Classification' , y='Balance' , data = df , palette = 'rainbow');


# In[33]:


sns.boxplot(x='Region' , y='Balance' , data = df , palette = 'rainbow');


# In[34]:


fig = plt.figure(figsize=(10,6)) # define plot area
sns.boxplot(x='Gender' , y='Balance' , data = df , hue = 'Region' , palette = 'rainbow');


# In[35]:


fig = plt.figure(figsize=(10,6)) # define plot area
sns.boxplot(x='Gender' , y='Balance' , data = df , hue = 'Job Classification' , palette = 'rainbow');


# In[36]:


fig = plt.figure(figsize=(10,6)) # define plot area
sns.boxplot(x='Gender' , y='Balance' , data = df , hue = 'Region' , palette = 'rainbow');


# In[37]:


fig = plt.figure(figsize=(10,6)) # define plot area
sns.boxplot(x='Job Classification' , y='Balance' , data = df , hue = 'Gender' , palette = 'rainbow');


# In[38]:


fig = plt.figure(figsize=(10,6)) # define plot area
sns.boxplot(x='Job Classification' , y='Balance' , data = df , hue = 'Region' , palette = 'rainbow');


# In[39]:


fig = plt.figure(figsize=(10,6)) # define plot area
sns.boxplot(x='Region' , y='Balance' , data = df , hue = 'Gender' , palette = 'rainbow');


# In[40]:


fig = plt.figure(figsize=(10,6)) # define plot area
sns.boxplot(x='Region' , y='Balance' , data = df , hue = 'Job Classification' , palette = 'rainbow');


# # Inferences

# Median Balance almost the same across Gender , Job Classification and Regions
# 
# England has the higer number of Account Balance Outliers across categories¶
# 
